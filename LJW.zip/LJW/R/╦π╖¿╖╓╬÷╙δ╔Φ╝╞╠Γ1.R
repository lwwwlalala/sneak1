# �㷨�����������1
#���ļ���������ע��ͻȻ������룬����UTF-8�޷����������Ӱ�����ʹ��
# This is an example function named '�㷨�����������1'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'


library(beepr)
dev.new()
source(file="game.r") #??????Ϸ????
# ??ʼ????????��
init<-function(){
  e<<-new.env()
  e$stage<-0 #????
  e$width<-e$height<-20  #?зָ???
  e$step<-1/e$width #????
  e$m<-matrix(rep(0,e$width*e$height),nrow=e$width)  #??????
  e$dir<-e$lastd<-'up' # ?ƶ?????
  e$head<-c(2,2) #??ʼ??ͷ
  e$lastx<-e$lasty<-2 # ??ʼ????ͷ??һ????
  e$tail<-data.frame(x=c(),y=c())#??ʼ??β

  e$col_furit<-2 #ˮ????ɫ
  e$col_head<-4 #??ͷ??ɫ
  e$col_tail<-8 #??β??ɫ
  e$col_path<-0 #·??ɫ
  e$score<0 #????
  e$col_obstruction<-9#??ɫ?ϰ???
}


# ???þ?????????ֵ
index<-function(col) which(e$m==col)

# ??Ϸ??
stage1<-function(){
  e$stage<-1
  #?÷?
  score<-function(){   #????score????
    #????Ϸ??ҳ?潨��text???????ӵ?ǰ?ķֵ????֣?λ????ҳ?????Ͻǣ???????СΪ0.9????ɫΪ??ɫ
    text(0.8,0.9,label=paste("[??ǰ?÷֣?",nrow(e$tail),"??]"),cex=0.9,col=8)

  }
  # ??????ˮ????
  furit<-function(){
    if(length(index(e$col_furit))<=0){ #??????ˮ??
      idx<-sample(index(e$col_path),1)

      fx<-ifelse(idx%%e$width==0,10,idx%%e$width)
      fy<-ceiling(idx/e$height)
      e$m[fx,fy]<-e$col_furit

      print(paste("furit idx",idx))
      print(paste("furit axis:",fx,fy))
    }
  }
  #?ϰ??????ƶ?
  obstruction<-function(){
    if(length(index(e$col_obstruction))<=0){
      idx<-sample(index(e$col_path),1)
      # if(obsteuctionMove)
      # {
      #   e$m[,"x"]<<-e$m[,"x"]+1
      #   colnames(e$m<-matrix)<<-as.numeric(colnames(e$m<-matrix))+1
      # }
      fx<-10
      fy<-10
      e$m[fx,fy]<-e$col_obstruction

      print(paste("idx",idx+1))
      print(paste("obstruction axis:",fx,fy))
    }
  }

  # ????ʧ??
  fail<-function(){
    # head???߽?
    if(length(which(e$head<1))>0 | length(which(e$head>e$width))>0){
      print("game over: Out of ledge.")
      keydown('q')
      beep(1)
      return(TRUE)
    }

    # head????tail
    if(e$m[e$head[1],e$head[2]]==e$col_tail){
      print("game over: head hit tail")
      keydown('q')
      beep(1)
      return(TRUE)
    }

    #head?????ϰ???
    if(e$m[e$head[1],e$head[2]]==e$col_obstruction){#??head?????ϰ???
      print("game over: head hit obstruction")  #????ʧ????Ϣ
      keydown('q')
      beep(1)
      return(TRUE)
    }
    #tail?????ϰ???
    # if(e$m[e$tail[1],e$tail[2]]==e$col_obstruction){
    #   print("game over: tail hit obstruction")
    #   keydown('q')
    #   return(TRUE)
    # }
    beep(1)
    return(FALSE)
  }


  # ̰???ߵ?ͷ??
  head<-function(){
    e$lastx<-e$head[1]
    e$lasty<-e$head[2]

    # ????????
    if(e$dir=='up') e$head[2]<-e$head[2]+1
    if(e$dir=='down') e$head[2]<-e$head[2]-1
    if(e$dir=='left') e$head[1]<-e$head[1]-1
    if(e$dir=='right') e$head[1]<-e$head[1]+1

  }

  # ̰???ߵ?????
  body<-function(){
    e$m[e$lastx,e$lasty]<-0
    e$m[e$head[1],e$head[2]]<-e$col_head #snake
    if(length(index(e$col_furit))<=0){ #??????ˮ??
      e$tail<-rbind(e$tail,data.frame(x=e$lastx,y=e$lasty))
    }
    # if(length(nrow(e$tail)/3==0)){ #3??ˮ??
    #   e$tail<-rbind(e$tail,data.frame(x=e$lastx,y=e$lasty))+2
    # }
    if(nrow(e$tail)>0) { #??????β??
      e$tail<-rbind(e$tail,data.frame(x=e$lastx,y=e$lasty))
      e$m[e$tail[1,]$x,e$tail[1,]$y]<-e$col_path
      e$tail<-e$tail[-1,]
      e$m[e$lastx,e$lasty]<-e$col_tail
    }


    print(paste("snake idx",index(e$col_head)))
    print(paste("snake axis:",e$head[1],e$head[2]))
  }


  # ????????
  drawTable<-function(){
    plot(0,0,xlim=c(0,1),ylim=c(0,1),type='n',xaxs="i", yaxs="i")
  }

  # ???ݾ?????????
  drawMatrix<-function(){
    idx<-which(e$m>0)
    px<- (ifelse(idx%%e$width==0,e$width,idx%%e$width)-1)/e$width+e$step/2
    py<- (ceiling(idx/e$height)-1)/e$height+e$step/2
    pxy<-data.frame(x=px,y=py,col=e$m[idx])
    points(pxy$x,pxy$y,col=pxy$col,pch=15,cex=4.4)
  }

  furit()
  head()

  if(!fail()){
    body()
    drawTable()
    drawMatrix()
    score()#????score
    obstruction()
  }
}


# ??????ͼ
stage0<-function(){
  e$stage<-0
  plot(0,0,xlim=c(0,1),ylim=c(0,1),type='n',xaxs="i", yaxs="i")
  text(0.5,0.7,label="Snake Game",cex=5)
  text(0.5,0.4,label="Any keyboard to start",cex=2,col=4)
  text(0.5,0.3,label="Up,Down,Left,Rigth to control direction",cex=2,col=2)
  text(0.2,0.05,label="Author:DanZhang",cex=1)
  text(0.5,0.05,label="http://blog.fens.me",cex=1)
}

# ??????ͼ
stage2<-function(){
  e$stage<-2
  plot(0,0,xlim=c(0,1),ylim=c(0,1),type='n',xaxs="i", yaxs="i")
  text(0.5,0.7,label="Game Over",cex=5)
  text(0.5,0.4,label="Space to restart, q to quit.",cex=2,col=4)
  text(0.5,0.3,label=paste("Congratulations! You have eat",nrow(e$tail),"fruits!"),cex=2,col=2)
  text(0.2,0.05,label="Author:DanZhang",cex=1)
  text(0.5,0.05,label="http://blog.fens.me",cex=1)
  beep(1)
}
#??ͣ??ͼ
stage3<-function(){  #??��stage3????
  e$stage<-3         #????e$stage
  plot(0,0,xlim=c(0,1),ylim=c(0,1),type='n',xaxs="i", yaxs="i")  #plot??ͼ
  text(0.5,0.7,label="pause",cex=5)                              #textд??pause
  text(0.5,0.4,label="Press the p key again to end the pause.",cex=2,col=4)#textд????
}

# ?????¼?
keydown<-function(K){
  print(paste("keydown:",K,",stage:",e$stage));

  if(e$stage==0){ #????????
    init()
    stage1()
    return(NULL)
  }

  if(e$stage==2){ #????????
    if(K=="q") q()
    else if(K==' ') stage0()
    return(NULL)
  }

  if(e$stage==1){ #??Ϸ??
    if(K == "q") {
      stage2()
    } else  {
      if(tolower(K) %in% c("up","down","left","right")){
        e$lastd<-e$dir
        e$dir<-tolower(K)
        stage1()
      }
    }
  }
  if(e$stage==1){ #????Ϸ??ҳ??ʱ
    if(K == "p"){ #??p??
      stage3()    #??ת??stage3??ͣҳ??
      return(NULL)
    }
  }
  if(e$stage==3){ #????ͣҳ??ʱ
    if(K == "p"){ #??p??
      stage1()    #??ת??stage1??Ϸ??ҳ??
    }
  }
  return(NULL)
}

#######################################
# RUN
#######################################

run<-function(){
  par(mai=rep(0,4),oma=rep(0,4))
  e<<-new.env()
  stage0()

  # ע???¼?
  getGraphicsEvent(prompt="Snake Game",onKeybd=keydown)
}

run()
